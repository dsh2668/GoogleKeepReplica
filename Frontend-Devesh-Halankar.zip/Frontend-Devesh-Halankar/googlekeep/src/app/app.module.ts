import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { MaterialModule } from './material.module';
import { LoginRegisterComponent } from './components/login-register/login-register.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NotesChecklistComponent } from './components/notes-checklist/notes-checklist.component';
import { AddNoteChecklistComponent } from './components/add-note-checklist/add-note-checklist.component';
import { MAT_DIALOG_DEFAULT_OPTIONS } from '@angular/material';
import { RichTextEditorModule } from '@syncfusion/ej2-angular-richtexteditor';
import { CheckListComponent } from './components/check-list/check-list.component';
import { FilterPipe } from './utility/filterpipe';
import { ConfirmDialogComponent } from './components/confirm-dialog/confirm-dialog.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginRegisterComponent,
    NotesChecklistComponent,
    AddNoteChecklistComponent,
    CheckListComponent,
    FilterPipe,
    ConfirmDialogComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
    RichTextEditorModule
  ],
  providers: [
    {provide: MAT_DIALOG_DEFAULT_OPTIONS, useValue: {hasBackdrop: true}}
  ],
  bootstrap: [AppComponent],
  entryComponents: [
    AddNoteChecklistComponent,
    CheckListComponent,
    ConfirmDialogComponent
  ]
})
export class AppModule { }
