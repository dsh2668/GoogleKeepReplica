import { Injectable } from '@angular/core';
import { User } from '../models/classes';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  loggedInUser: User = null;

  constructor() { }
}
