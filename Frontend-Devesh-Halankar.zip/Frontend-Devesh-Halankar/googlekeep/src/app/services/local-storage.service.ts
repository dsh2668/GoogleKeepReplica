import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LocalStorageService {

  constructor() { }

  getLocalStorage() {
    const localStorageData = JSON.parse(localStorage.getItem('data'));
    return localStorageData === null ? [] : localStorageData;
  }

  setLocalStorage(data) {
    localStorage.setItem('data', JSON.stringify(data));
  }

}
