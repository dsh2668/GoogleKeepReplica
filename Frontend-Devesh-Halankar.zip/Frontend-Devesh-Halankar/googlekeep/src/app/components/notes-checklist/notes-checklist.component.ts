import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';
import { UserData, User } from '../../models/classes';
import { AddNoteChecklistComponent } from '../add-note-checklist/add-note-checklist.component';
import { LoginService } from '../../services/login.service';
import { DomSanitizer } from '@angular/platform-browser';
import { LocalStorageService } from '../../services/local-storage.service';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-notes-checklist',
  templateUrl: './notes-checklist.component.html',
  styleUrls: ['./notes-checklist.component.css']
})
export class NotesChecklistComponent implements OnInit {

  searchString = '';
  loggedInUser: User;

  constructor(
    public dialog: MatDialog,
    private loginService: LoginService,
    public sanitizer: DomSanitizer,
    private localStorageService: LocalStorageService
  ) {
    this.loggedInUser = this.loginService.loggedInUser;
  }

  ngOnInit() {
  }

  openNoteCheckListEditor(isNote: boolean, userData: UserData) {
    this.dialog.open(AddNoteChecklistComponent, {
      disableClose: true,
      width: '50%',
      data: { isNote: isNote, userData: userData }
    }).afterClosed().subscribe(
      result => {
        const localStorageData = this.localStorageService.getLocalStorage();
        for (const eachUser of localStorageData) {
          if (eachUser.loginId === this.loggedInUser.loginId) {
            this.loginService.loggedInUser = eachUser;
            this.loggedInUser = eachUser;
            break;
          }
        }
      });
  }

  deleteUserData(eachDataItem: UserData) {
    this.dialog.open(ConfirmDialogComponent).afterClosed()
      .subscribe(result => {
        if (result) {
          const localStorageData = this.localStorageService.getLocalStorage();
          for (const eachUser of localStorageData) {
            if (eachUser.loginId === this.loggedInUser.loginId) {
              for (const eachUserData of eachUser.data) {
                if (eachUserData.id === eachDataItem.id) {
                  eachUser.data.splice(eachUser.data.indexOf(eachUserData), 1);
                  this.loginService.loggedInUser = eachUser;
                  this.loggedInUser = eachUser;
                  break;
                }
              }
              break;
            }
          }
          this.localStorageService.setLocalStorage(localStorageData);
        }
      });
  }

  logOut() {
    const localStorageData = this.localStorageService.getLocalStorage();
    for (const eachUser of localStorageData) {
      if (eachUser.loginId === this.loggedInUser.loginId) {
        eachUser.loggedIn = false;
        break;
      }
    }
    this.localStorageService.setLocalStorage(localStorageData);
    this.loginService.loggedInUser = null;
    this.loggedInUser = null;
  }

}
