import { Component, OnInit, Input } from '@angular/core';
import { CheckListItem, UserData } from '../../models/classes';
import { MatDialog } from '@angular/material';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-check-list',
  templateUrl: './check-list.component.html',
  styleUrls: ['./check-list.component.css']
})
export class CheckListComponent implements OnInit {

  @Input() userData = new UserData();
  @Input() disabled = true;

  checked = false;

  constructor(
    private dialog: MatDialog
  ) { }

  ngOnInit() {
  }

  addItemToCheckList() {
    this.userData.data.push(new CheckListItem());
  }

  onChangeListItem(eachCheckListItem: CheckListItem) {
    if (eachCheckListItem.itemName === '' || eachCheckListItem.itemName === null || eachCheckListItem.itemName === undefined) {
      this.userData.data.splice(this.userData.data.indexOf(eachCheckListItem), 1);
    }
  }

  onDeleteListItem(eachCheckListItem: CheckListItem) {
    this.dialog.open(ConfirmDialogComponent).afterClosed()
      .subscribe(result => {
        if (result) {
          this.userData.data.splice(this.userData.data.indexOf(eachCheckListItem), 1);
        }
      });
  }

}
