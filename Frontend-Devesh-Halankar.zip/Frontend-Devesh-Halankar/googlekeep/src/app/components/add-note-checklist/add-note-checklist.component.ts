import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ToolbarService, LinkService, ImageService, HtmlEditorService } from '@syncfusion/ej2-angular-richtexteditor';
import { UserData, CheckListItem } from '../../models/classes';
import { LocalStorageService } from '../../services/local-storage.service';
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-add-note-checklist',
  templateUrl: './add-note-checklist.component.html',
  styleUrls: ['./add-note-checklist.component.css'],
  providers: [ToolbarService, LinkService, ImageService, HtmlEditorService]
})
export class AddNoteChecklistComponent implements OnInit {

  public tools: object = {
    items: ['Undo', 'Redo', '|',
      'Bold', 'Italic', 'Underline', 'StrikeThrough', '|',
      'FontName', 'FontSize', 'FontColor', 'BackgroundColor', '|',
      'SubScript', 'SuperScript', '|',
      'LowerCase', 'UpperCase', '|',
      'Formats', 'Alignments', '|', 'OrderedList', 'UnorderedList', '|',
      'Indent', 'Outdent', '|', 'CreateLink',
      'Image', '|', 'ClearFormat']
  };
  public quickTools: object = {
    image: [
      'Replace', 'Align', 'Caption', 'Remove', 'InsertLink', '-', 'Display', 'AltText', 'Dimension']
  };

  public insertImageSettings = {
    allowedTypes: ['.jpeg', '.jpg', '.png'],
    display: 'inline',
    width: 'auto',
    height: 'auto',
  };

  isNote = true;
  userData = null;

  constructor(
    public dialogRef: MatDialogRef<AddNoteChecklistComponent>,
    @Inject(MAT_DIALOG_DATA) public data,
    private localStorageService: LocalStorageService,
    private loginService: LoginService
  ) {
    this.isNote = this.data.isNote;
    this.userData = this.data.userData;
    if (this.userData === null) {
      this.userData = new UserData();
      this.userData.note = this.isNote;
      if (this.isNote) {
        this.userData.data = '';
      } else {
        this.userData.data = new Array<CheckListItem>();
      }
    }
    console.log(this.isNote);
    console.log(this.userData);
  }

  ngOnInit() {
  }

  saveData() {
    if (this.userData.title !== '' && this.userData.title !== null && this.userData.title !== undefined) {
      const localStorageData = this.localStorageService.getLocalStorage();
      for (const eachUser of localStorageData) {
        if (eachUser.loginId === this.loginService.loggedInUser.loginId) {
          let id = 0;
          if (this.userData.id === null) {
            for (const eachUserData of eachUser.data) {
              if (eachUserData.id > id) {
                id = eachUserData.id;
              }
            }
            id++;
            this.userData.id = id;
            eachUser.data.push(this.userData);
            break;
          } else {
            for (const eachUserData of eachUser.data) {
              if (eachUserData.id === this.userData.id) {
                eachUserData.data = this.userData.data;
                eachUserData.title = this.userData.title;
                break;
              }
            }
          }
          break;
        }
      }
      this.localStorageService.setLocalStorage(localStorageData);
      this.closeDialog(true);
    } else {
      alert('Please add title!');
    }
  }

  closeDialog(result = false) {
    this.dialogRef.close(result);
  }

}
