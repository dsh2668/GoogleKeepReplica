import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import * as CryptoJS from 'crypto-js';
import { User } from '../../models/classes';
import { LocalStorageService } from '../../services/local-storage.service';
import { LoginService } from '../../services/login.service';

@Component({
  selector: 'app-login-register',
  templateUrl: './login-register.component.html',
  styleUrls: ['./login-register.component.css']
})
export class LoginRegisterComponent implements OnInit {

  formRegister: FormGroup;
  formLogin: FormGroup;

  constructor(
    private localStorageService: LocalStorageService,
    private loginService: LoginService
  ) { }

  ngOnInit() {
    this.createForm();
  }

  createForm() {
    this.formLogin = new FormGroup({
      loginId: new FormControl('', [Validators.required, Validators.minLength(4), Validators.maxLength(20)]),
      password: new FormControl('', [Validators.required, Validators.minLength(4), Validators.maxLength(25)])
    });
    this.formRegister = new FormGroup({
      name: new FormControl('', [Validators.required, Validators.minLength(4), Validators.maxLength(100)]),
      loginId: new FormControl('', [Validators.required, Validators.minLength(4), Validators.maxLength(20)]),
      password: new FormControl('', [Validators.required, Validators.minLength(4), Validators.maxLength(25)]),
      confirmPassword: new FormControl('', [Validators.required, Validators.minLength(4), Validators.maxLength(25)])
    });
  }

  onRegister(registerData) {
    if (registerData.password === registerData.confirmPassword && this.formRegister.valid) {
      const password = CryptoJS.AES.encrypt(registerData.password.trim(), 'pass').toString();
      console.log(registerData);
      const user = new User();
      user.name = registerData.name;
      user.password = password;
      user.loginId = registerData.loginId;
      const localStorageData: Array<User> = this.localStorageService.getLocalStorage();
      let userAlreadyExists = false;
      for (const eachUser of localStorageData) {
        if (eachUser.loginId === user.loginId) {
          userAlreadyExists = true;
          break;
        }
      }
      if (userAlreadyExists) {
        alert('Login ID already exists!');
      } else {
        localStorageData.push(user);
        this.localStorageService.setLocalStorage(localStorageData);
        alert('User Registered Successfully!');
        this.formRegister.reset();
      }
    } else {
      if (this.formRegister.valid) {
        alert('Passwords do not match!');
      } else {
        Object.keys(this.formRegister.controls).forEach(field => {
          const control = this.formRegister.controls[field];
          control.markAsTouched({ onlySelf: true });
        });
      }
    }
  }

  onLogin(loginData) {
    if (this.formLogin.valid) {
      const localStorageData: Array<User> = this.localStorageService.getLocalStorage();
      let userExists = false;
      let loggedInUser: User = null;
      if (localStorageData.length > 0) {
        for (const eachUser of localStorageData) {
          const userPassword = CryptoJS.AES.decrypt(eachUser.password.trim(), 'pass').toString(CryptoJS.enc.Utf8);
          if (eachUser.loginId === loginData.loginId && userPassword === loginData.password) {
            userExists = true;
            eachUser.loggedIn = true;
            loggedInUser = eachUser;
          } else {
            eachUser.loggedIn = false;
          }
        }
      }
      if (userExists) {
        this.loginService.loggedInUser = loggedInUser;
      } else {
        alert('User does not exists');
        this.loginService.loggedInUser = null;
      }
      this.localStorageService.setLocalStorage(localStorageData);
    } else {
      Object.keys(this.formLogin.controls).forEach(field => {
        const control = this.formLogin.controls[field];
        control.markAsTouched({ onlySelf: true });
      });
    }
  }

}
