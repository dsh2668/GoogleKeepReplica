import { Pipe, PipeTransform, Injectable } from '@angular/core';
@Pipe({
  name: 'filter'
})
@Injectable()
export class FilterPipe implements PipeTransform {
  transform(items: any[], field: string[], value: string): any[] {
    let resultArray = [];
    if (!items) {
      return [];
    }
    if (!field || !value) {
      return items;
    }
    resultArray = items.filter(singleItem => {
      if (!singleItem.note) {
        for (const eachField of field) {
          if (eachField !== 'data' && singleItem[eachField].toString().toLowerCase().includes(value.toLowerCase())) {
            return true;
          } else if (eachField === 'data') {
            return JSON.stringify(singleItem.data).toString().toLowerCase().includes(value.toLowerCase());
          } else {
            return false;
          }
        }
      } else {
        for (const eachField of field) {
          if (singleItem[eachField].toString().toLowerCase().includes(value.toLowerCase())) {
            return true;
          } else {
            return false;
          }
        }
      }
    });
    return resultArray;
  }

}
