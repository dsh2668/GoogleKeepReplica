export class User {
  name: string = null;
  loginId: string = null;
  password: string = null;
  loggedIn = false;
  data = new Array<UserData>();
}

export class UserData {
  id: number = null;
  note = true; // false if check list
  title: string = null;
  data = null;
  location: any;
}

export class CheckListItem {
  itemName: string = null;
  checked = false;
}
