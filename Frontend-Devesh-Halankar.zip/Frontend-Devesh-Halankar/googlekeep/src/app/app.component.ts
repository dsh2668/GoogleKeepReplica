import { Component, OnInit } from '@angular/core';
import { LoginService } from './services/login.service';
import { LocalStorageService } from './services/local-storage.service';
import { User } from './models/classes';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'googlekeep';

  constructor (
    public loginService: LoginService,
    private localStorageService: LocalStorageService
  ) { }

  ngOnInit(): void {
    const localStorageData: Array<User> = this.localStorageService.getLocalStorage();
    for (const eachUser of localStorageData) {
      if (eachUser.loggedIn) {
        this.loginService.loggedInUser = eachUser;
        break;
      }
    }
  }

}
