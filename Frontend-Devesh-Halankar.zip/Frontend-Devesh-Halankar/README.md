I have used Angular 2+ to develop the project.

The package.json file in the project has all the required dependencies listed.
Using the command npm install will download all the dependencies for the project.

To run the project, execute the command ng serve, once all the dependencies have been downloaded.
The project runs on the default port for Angular Projects, i.e. 4200.
